blocking<-function(learn = 1/3,
                     sub = 25,
                     num_of_trials = 50,
                     num_items = 80
){
  A<-matrix(c(rep(1,20),rep(0,(num_items-20))),nrow = 1)
  B<-matrix(c(rep(0,(20)),rep(1,20),rep(0,num_items-40)),nrow = 1)
  D<-matrix(c(rep(0,(40)),rep(1,20),rep(0,num_items-60)),nrow = 1)
  X<-matrix(c(rep(0,(num_items-20)),rep(1,20)),nrow = 1)
  C<-matrix(c(rep(0,(num_items-40)),rep(0,20),rep(0,20)),nrow = 1)
  AX<-A+X+C
  AB<-A+B+C
  DX<-D+X+C
  ABX<-A+B+C+X
  D<-D+C
  A<-A+C
  B<-B+C
  X<-X+C
  recall_list<-c()
  x_b1<-c()
  x_b2<-c()
  x_b3<-c()
  #learn<-1/3
  #sub<-10
  for (k in 1:sub){
    memory<-initiate_memory(num_items)
    for (i in 1:num_of_trials){
      s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),AX[,1:(num_items-20)],cosine = TRUE)
      a<-get_activation(s)
      e<-get_echo(a,memory)
      e<-add_noise(e)
      memory<-add_to_memory(AX-e,memory,L=learn)
      recall_list<-c(recall_list,sim_x_given_a(X[(num_items-19):(num_items)],e[(num_items-19):(num_items)]))
    }
    for (i in 1:num_of_trials){
      s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),ABX[,1:(num_items-20)],cosine = TRUE)
      a<-get_activation(s)
      e<-get_echo(a,memory)
      e<-add_noise(e)
      memory<-add_to_memory(ABX-e,memory,L=learn)
      recall_list<-c(recall_list,sim_x_given_a(X[(num_items-19):(num_items)],e[(num_items-19):(num_items)]))
    }

    s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),B[,1:(num_items-20)],cosine = TRUE)
    a<-get_activation(s)
    e<-get_echo(a,memory)
    x_b1<-c(x_b1,sim_x_given_a(X[(num_items-19):(num_items)],e[(num_items-19):(num_items)]))

    ##############################Control 1#########################################
    memory<-initiate_memory(num_items)
    for (i in 1:num_of_trials){
      s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),DX[,1:(num_items-20)],cosine = TRUE)
      a<-get_activation(s)
      e<-get_echo(a,memory)
      e<-add_noise(e)
      memory<-add_to_memory(DX-e,memory,L=learn)
      recall_list<-c(recall_list,sim_x_given_a(X[(num_items-19):(num_items)],e[(num_items-19):(num_items)]))
    }
    for (i in 1:num_of_trials){
      s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),ABX[,1:(num_items-20)],cosine = TRUE)
      a<-get_activation(s)
      e<-get_echo(a,memory)
      e<-add_noise(e)
      memory<-add_to_memory(ABX-e,memory,L=learn)
      recall_list<-c(recall_list,sim_x_given_a(X[(num_items-19):(num_items)],e[(num_items-19):(num_items)]))
    }

    s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),B[,1:(num_items-20)],cosine = TRUE)
    a<-get_activation(s)
    e<-get_echo(a,memory)
    x_b2<-c(x_b2,sim_x_given_a(X[(num_items-19):(num_items)],e[(num_items-19):(num_items)]))

    ##############################Control 2#########################################

    memory<-initiate_memory(num_items)
    for (i in 1:num_of_trials){
      s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),ABX[,1:(num_items-20)],cosine = TRUE)
      a<-get_activation(s)
      e<-get_echo(a,memory)
      e<-add_noise(e)
      memory<-add_to_memory(ABX-e,memory,L=learn)
      recall_list<-c(recall_list,sim_x_given_a(X[(num_items-19):(num_items)],e[(num_items-19):(num_items)]))
    }

    s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),B[,1:(num_items-20)],cosine = TRUE)
    a<-get_activation(s)
    e<-get_echo(a,memory)
    x_b3<-c(x_b3,sim_x_given_a(X[(num_items-19):(num_items)],e[(num_items-19):(num_items)]))
  }


  # print(mean(x_b))
  # print(sd(x_b))

  table2<-data.frame(matrix(c("A->X", "C->X", "", "AB->X","AB->X","AB->X","X|B","X|B","X|B", mean(x_b1),mean(x_b2),mean(x_b3),sd(x_b1),sd(x_b2),sd(x_b3)), nrow = 3,byrow = F))
  rownames(table2)<-c("Blocking","Control(1)","Control(2)")
  colnames(table2)<-c("Training 1","Training 2", "Test","mean","sd")
  print(table2)
  # table2<-data.frame(matrix(c(mean(x_a),mean(x_b),sd(x_a),sd(x_a)), nrow = 2,byrow = F))
  # rownames(table2)<-c("X|A","X|B")
  # colnames(table2)<-c("mean","sd")
  # print(table2)

}

#" Square function
#" @param number
#" #return square
#" @export


square<-function(x){
  return(x^2)
}

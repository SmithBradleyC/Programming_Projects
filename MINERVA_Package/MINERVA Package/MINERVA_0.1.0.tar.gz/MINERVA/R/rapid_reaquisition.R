rapid_reaquisition<-function(learn = 1/3,
                      sub = 25,
                      num_items = 120)
  {
  num_of_trials<-100
  A<-matrix(c(rep(1,20),rep(0,(num_items-20))),nrow = 1)
  B<-matrix(c(rep(0,(20)),rep(1,20),rep(0,num_items-40)),nrow = 1)
  X<-matrix(c(rep(0,(num_items-20)),rep(1,20)),nrow = 1)
  C<-matrix(c(rep(0,(num_items-40)),rep(1,20),rep(0,20)),nrow = 1)
  AX<-A+X+C
  BX<-A+X+C
  A<-A+C
  B<-B+C
  X<-X+C
  recall_list<-c()
  count_a_list<-c()
  count_b_list<-c()
  #learn<-1/3
  #sub<-10
  for (k in 1:sub){
    memory<-initiate_memory(num_items)
    for (i in 1:num_of_trials){
      s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),AX[,1:(num_items-20)],cosine = TRUE)
      a<-get_activation(s)
      e<-get_echo(a,memory)
      disc<-AX-e
      disc<-add_noise(disc)
      memory<-add_to_memory(disc,memory,L=learn)
      #e<-add_noise(e)
      #memory<-add_to_memory(AX-e,memory,L=learn)
      recall_list<-c(recall_list,sim_x_given_a(X[(num_items-19):(num_items)],e[(num_items-19):(num_items)]))
    }
    for (i in 1:num_of_trials){
      s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),A[,1:(num_items-20)],cosine = TRUE)
      a<-get_activation(s)
      e<-get_echo(a,memory)
      disc<-A-e
      disc<-add_noise(disc)
      memory<-add_to_memory(disc,memory,L=learn)
      #e<-add_noise(e)
      #memory<-add_to_memory(A-e,memory,L=learn)
      recall_list<-c(recall_list,sim_x_given_a(X[(num_items-19):(num_items)],e[(num_items-19):(num_items)]))
    }
    count_a<-0
    count_b<-0
    x_a<-0
    x_b<-0
    memory_a<-memory
    memory_b<-memory

    # print(memory)
    # print(memory_a == memory)
    # recall<-matrix(recall_list,nrow = sub,byrow = TRUE)
    # ret_X<-colSums(recall)/sub
    # par(mfrow = c(1,1))
    # plot(1:length(ret_X),ret_X,ylim = c(0,1), ylab = "Average Retrieval of X|A", xlab = "Trial")
    repeat{
      if ((x_a >= 0.95) & (x_b >= 0.95)){break}
      if (x_a < 0.95){
        s_a<-get_similarity(matrix(memory_a[,1:(num_items-20)],nrow = nrow(memory_a)),AX[,1:(num_items-20)],cosine = TRUE)
        a_a<-get_activation(s_a)
        e_a<-get_echo(a_a,memory_a)
        disc_a<-AX-e_a
        disc_a<-add_noise(disc_a)
        memory_a<-add_to_memory(disc_a,memory_a,L=learn)
        count_a<-count_a+1
        x_a<-sim_x_given_a(X[(num_items-19):(num_items)],e_a[(num_items-19):(num_items)])
        if (x_a >= 0.95){count_a_list<-c(count_a_list,count_a)}
      }

      if (x_b < 0.95){
        s_b<-get_similarity(matrix(memory_b[,1:(num_items-20)],nrow = nrow(memory_b)),BX[,1:(num_items-20)],cosine = TRUE)
        a_b<-get_activation(s_b)
        e_b<-get_echo(a_b,memory_b)
        disc_b<-BX-e_b
        disc_b<-add_noise(disc_b)
        memory_b<-add_to_memory(disc_b,memory_b,L=learn)
        count_b<-count_b+1
        x_b<-sim_x_given_a(X[(num_items-19):(num_items)],e_b[(num_items-19):(num_items)])
        if (x_b >= 0.95){count_b_list<-c(count_b_list,count_b)}
      }
       print(x_a)
       print(x_b)

    }
  }


  print(mean(count_a_list))
  print(mean(count_b_list))
  #recall<-matrix(recall_list,nrow = sub,byrow = TRUE)
  #ret_X<-colSums(recall)/sub

  # if (show_acquisition == T){
  #   Learning_Curve<-plot(1:length(ret_X),ret_X,ylim = c(0,1), ylab = "Average Retrieval of X|A", xlab = "Trial")
  #   #ret<-list(Learning_Curve,ret_X)
  #   #names(ret)<-c("Learning Curve","Retrieval of X|A")
  #   #return(ret)
  # }else{
  #   Learning_Curve<-plot((num_of_trials+1):length(ret_X),ret_X[(num_of_trials+1):length(ret_X)],ylim = c(0,1), ylab = "Average Retrieval of X|A", xlab = "Trial")
  #   #ret<-list(Learning_Curve,ret_X[(num_of_trials+1):length(ret_X)])
  #   #names(ret)<-c("Learning Curve","Retrieval of X|A")
  #   #return(ret)
  # }
}

schema_abstraction<-function(sub = 50,
                             num_items =40,
                             distortion_proportion = 0.3,
                             number_of_categories = 3,
                             # list specifying number in each category
                             frequency_of_categories = c(10,50,100),
                             number_of_distractors = 0,
                             forget_proportion = 0.75,
                             present_names = T,
                             type = "normed",
                             sig_digits = 2,
                             hideplot = F,
                             num_bootstrap = 1,
                             name_first = T,
                             ...){

  # for when you want to do the follow up test with forgetting
  L = 1-forget_proportion

  # if the parameters don't match up flag error
  if (number_of_categories != length(frequency_of_categories)){stop("Must specify how many instances in each category")}

  # number of items must be even
  if (num_items%%2 != 0){stop("num_items must be even for this function to work")}

  # make a matrix to store the prototypes in to remember later
  prototype_matrix<-matrix(ncol = num_items,nrow = 0)
  for (i in 1:number_of_categories){
    prototype<-make_instance(num_items = num_items)
    prototype_matrix<-rbind(prototype_matrix,prototype)
  }

  # set up items to be able to average intensity and echo over participants
  t_intensity<-0
  t_echo<-0

  # repeat experiment with same prototypes over several participants
  for (par in 1:sub){

    # initiate memory
    memory<-initiate_memory(num_items = num_items)

    for (i in 1:number_of_categories){
      prototype<-prototype_matrix[i,]
      for (y in 1:frequency_of_categories[i]){
        memory<-add_to_memory(add_distortion(instance = prototype,
                                             proportion = distortion_proportion,
                                             name_first = name_first),
                              memory = memory)
      }
    }
    #distractor<-make_instance(num_items = num_items)
    #prototype_matrix<-rbind(prototype_matrix,distractor)
    rownames(prototype_matrix)<-NULL

    # make a probe matrix for testing
    probe<-c()

    if (present_names == T){
      distractor<-make_instance(num_items = num_items)
      #prototype_matrix<-rbind(prototype_matrix,distractor)
      #rownames(prototype_matrix)<-NULL
      probe<-prototype_matrix
      probe<-rbind(probe,distractor)
      rownames(probe)<-NULL


      for (i in (num_items/2+1):num_items){
        probe[,i]<-c(rep(0,nrow(probe)))
      }

      names<-c()
      for (i in 1:number_of_categories){
        names<-c(names,paste("Prototype ",i))
      }
      names_col<-c(names,"Distractor")
      names_row<-c("Prototype", "Probe", "Echo", "Intensity", "Prototype:Echo Correlation")
      number_of_rows<-number_of_categories+1



    }
    if (present_names == F){

      # get an exemplar that had been stored for each prototype for the probe matrix
      for (i in 1:number_of_categories){
        exemplar<-memory[sum(frequency_of_categories[1:i]),]
        probe<-c(probe,exemplar,prototype_matrix[i,],add_distortion(prototype_matrix[i,],proportion = distortion_proportion,name_first = name_first))
      }
      probe<-c(probe,make_instance(num_items = num_items))
      probe<-matrix(probe,ncol=num_items,byrow = TRUE)
      prototype_matrix<-probe
      #prototype_matrix<-rbind(probe,make_instance(num_items = num_items))
      #print(prototype_matrix)


      for (i in 1:(num_items/2)){
        probe[,i]<-c(rep(0,nrow(probe)))
      }

      names<-c()
      for (i in 1:number_of_categories){
        names<-c(names,paste("Prototype ",i," (Exemplary in memory)"),"(Prototype)","(New Exemplar)")
      }
      names_col<-c(names,"Distractor")
      names_row<-c("Prototype ", "Probe", "Echo", "Intensity","Prototype:Echo Correlation")
      number_of_rows<-nrow(prototype_matrix)



    }

    similarity<-get_similarity(memory,t(probe))
    activation<-get_activation(similarity)

    intensity<-get_intensity(activation)
    echo<-get_echo(activation, memory,type = type)

    # sum up total intensity and echo
    t_intensity<-t_intensity+intensity
    t_echo<-t_echo+echo

  }

  # average out intensity and echo
  a_intensity<-t_intensity/sub
  a_echo<-t_echo/sub

  a_correlation<-c()
#  for (i in 1:(number_of_categories+1)){

  itera_number<-length(prototype_matrix[,1])
  if (present_names == T){itera_number<-itera_number+1}

  for (i in 1:itera_number){
    check<-length(a_correlation)
    #print(check)
    # print(a_echo[i,])
    # print(prototype_matrix[i,])
    # print("==================================")
    try(a_correlation[i]<-correlate_echo_names(echo = a_echo[i,], category = prototype_matrix[i,], name_first = name_first),silent = T)
    #print(check)
    if (length(a_correlation) == check){a_correlation[i]<-0}
  }
  #correlate_echo_names()

  # format data for output
  if (present_names == T){prototype_text<-apply(format(rbind(prototype_matrix,distractor)),1,paste,collapse=",")}
  else{prototype_text<-apply(format(prototype_matrix),1,paste,collapse=",")}
  probe_text<-apply(format(probe), 1, paste, collapse=",")
  # round_normed_echo_text<-apply(format(round(normed_echo,digits = 0)), 1, paste, collapse=",")
  # normed_echo_text<-apply(format(round(normed_echo,digits = 2)), 1, paste, collapse=",")
  echo_text<-apply(format(round(a_echo,digits = sig_digits)), 1, paste, collapse=",")
  par(mfrow=c((num_bootstrap+1),itera_number)) # num row, num col
  #print("here")
  if (hideplot == F){
  for (i in 1:itera_number){
    if (i == itera_number){
      if (present_names == T){barplot(distractor[half:full],ylim = c(-1,1),main = "Distractor",ylab = "Probe")
      }else{barplot(prototype_matrix[i,half:full], ylim = c(-1,1), main = "Distractor", ylab = "Probe")}
    }else{
    half<-(length(prototype_matrix[i,])/2+1)
    full<-(length(prototype_matrix[i,]))
    #print(half)
    #print(full)
    #print(prototype_matrix[i,half:full])

      barplot(prototype_matrix[i,half:full], ylim = c(-1,1), main = names[i], ylab = "Probe")

    }
  }
  }
  #print("he")
  for (i in 1:itera_number){
    if (hideplot == F){
      barplot(a_echo[i,half:full], ylim = c(-1,1), ylab = "Echo")
    }
  }

  return(as.table(matrix(c(prototype_text,probe_text,echo_text, round(a_intensity,digits = 3), round(a_correlation, digits = 3)),
                         nrow = number_of_rows, byrow = FALSE,
                         dimnames = list(names_col,names_row))))
}

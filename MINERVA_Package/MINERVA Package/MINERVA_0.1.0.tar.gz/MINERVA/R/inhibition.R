inhibition<-function(learn = 1/3,
                     sub = 25,
                     num_of_trials = 50,
                     num_items = 60
){
  A<-matrix(c(rep(1,20),rep(0,(num_items-20))),nrow = 1)
  B<-matrix(c(rep(0,(20)),rep(1,20),rep(0,num_items-40)),nrow = 1)
  X<-matrix(c(rep(0,(num_items-20)),rep(1,20)),nrow = 1)
  C<-matrix(c(rep(0,(num_items-40)),rep(0,20),rep(0,20)),nrow = 1)
  AX<-A+X+C
  AB<-A+B+C
  A<-A+C
  B<-B+C
  X<-X+C
  recall_list<-c()
  x_a<-c()
  x_b<-c()
  #learn<-1/3
  #sub<-10
  for (k in 1:sub){
    memory<-initiate_memory(num_items)
    for (i in 1:num_of_trials){
      s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),AX[,1:(num_items-20)],cosine = TRUE)
      a<-get_activation(s)
      e<-get_echo(a,memory)
      disc<-AX-e
      disc<-add_noise(disc)
      memory<-add_to_memory(disc,memory,L=learn)
      s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),AB[,1:(num_items-20)],cosine = TRUE)
      a<-get_activation(s)
      e<-get_echo(a,memory)
      disc<-AB-e
      disc<-add_noise(disc)
      memory<-add_to_memory(disc,memory,L=learn)
    }

    s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),A[,1:(num_items-20)],cosine = TRUE)
    a<-get_activation(s)
    e<-get_echo(a,memory)
    x_a<-c(x_a,sim_x_given_a(X[(num_items-19):(num_items)],e[(num_items-19):(num_items)]))

    s<-get_similarity(matrix(memory[,1:(num_items-20)],nrow = nrow(memory)),B[,1:(num_items-20)],cosine = TRUE)
    a<-get_activation(s)
    e<-get_echo(a,memory)
    x_b<-c(x_b,sim_x_given_a(X[(num_items-19):(num_items)],e[(num_items-19):(num_items)]))
  }

  # print(mean(x_a))
  # print(sd(x_a))
  # print(mean(x_b))
  # print(sd(x_b))
  table2<-data.frame(matrix(c("A->X/AB","","X|A","X|B",mean(x_a),mean(x_b),sd(x_a),sd(x_b)), nrow = 2,byrow = F))
  #rownames(table2)<-c("","")
  colnames(table2)<-c("Training","Test","mean","sd")
  print(table2)

  # recall<-matrix(recall_list,nrow = sub,byrow = TRUE)
  # ret_X<-colSums(recall)/sub
  #
  # par(mfrow = c(1,1))
  # if (show_acquisition == T){
  #   Learning_Curve<-plot(1:length(ret_X),ret_X,ylim = c(0,1), ylab = "Average Retrieval of X|A", xlab = "Trial")
  #   #ret<-list(Learning_Curve,ret_X)
  #   #names(ret)<-c("Learning Curve","Retrieval of X|A")
  #   #return(ret)
  # }else{
  #   Learning_Curve<-plot((num_of_trials+1):length(ret_X),ret_X[(num_of_trials+1):length(ret_X)],ylim = c(0,1), ylab = "Average Retrieval of X|A", xlab = "Trial")
  #   #ret<-list(Learning_Curve,ret_X[(num_of_trials+1):length(ret_X)])
  #   #names(ret)<-c("Learning Curve","Retrieval of X|A")
  #   #return(ret)
  # }
}

##################################################################################################################################################################

# Make each instance by randomly generating a string of items that are either -1 or 1
make_instance<-function(num_items=20){
  return(c((2*rbern(num_items,0.5)-1)))
}

##################################################################################################################################################################

# add a row to memory
add_to_memory<-function(instance,
                        memory,
                        L=1,
                        times = 1){

  for (i in 1:times){


    # add the instance to memory
    memory<-rbind(memory,instance)

    # Forget each feature in the added instance with probability 1-L
    count<-1
    for (i in instance){
      memory[nrow(memory),count]<-i*(rbern(1,L))
      count<-count+1
    }
  }
  # avoid naming rows
  row.names(memory)<-NULL
  return(memory)
}

##################################################################################################################################################################
# Forget each feature in memory with probability 1-L
forget_in_memory<-function(memory,
                           L=.25){
  for (i in 1:length(memory)){
    memory[i]<-memory[i]*(rbern(1,L))
  }
  return(memory)
}

##################################################################################################################################################################

# make an empty matrix for memory to be added in
initiate_memory<-function(num_items=20){
  return(matrix(ncol = num_items,nrow = 0))
}

##################################################################################################################################################################

# make a probe matrix from a list of test instances
make_probe_matrix<-function(test_instances,

                            # assume just probing one but option to test several
                            num_instances_to_probe = 1){
  return(matrix(test_instances,ncol = num_instances_to_probe))
}

##################################################################################################################################################################

# make a matrix as big as the resulting echo
# (usually just one vector because of just one item in the probe)
# it will calculate the "relevant n's" to divide by
get_divide_matrix<-function(memory,
                            probe){

  # make a matrix as large as the resulting intensities matrix and fill it with the max relevant n's
  divide<-matrix(data = c(rep(ncol(memory),(nrow(memory)*ncol(probe)))),byrow = TRUE,ncol = ncol(probe))

  # for each probe
  count_probe<-0
  while (count_probe < ncol(probe)){
    count_probe<-count_probe+1

    # for each row in memory
    count_row<-0
    while (count_row < nrow(memory)){
      count_row<-count_row+1

      # for each item in that row in memory
      count_col<-0
      while (count_col < ncol(memory)){
        count_col<-count_col+1

        # if both the item in memory and the item in the probe are 0 then subtract 1 from the proper spot in the divide matrix
        if (memory[count_row,count_col]==0){
          if (probe[count_col,count_probe]==0){
            divide[count_row,count_probe]<-divide[count_row,count_probe]-1
          }
        }
      }

    }
  }

  # returns a matrix of values that the make up the denominator for the similarity of the traces
  return(divide)
}

##################################################################################################################################################################

get_similarity<-function(memory,
                         probe,
                         cosine = FALSE,
                         divide = NULL){
  if (is.null(divide)){
    if (cosine == TRUE){
      divide = get_divide_matrix_cosine(memory,probe)
    }
    else {
      divide = get_divide_matrix(memory,probe)
    }
  }
  # get the numerator of the similarity
  try(similarity<-memory%*%probe,silent = F)

  if (nrow(memory)==0){similarity<-matrix(c(0),nrow = 1)}

  # divide each similarity numerator by the denominator calculated in divide_matrix()
  count<-0
  while (count < nrow(similarity)*ncol(similarity)){
    count<-count+1
    similarity[count]<-similarity[count]/divide[count]
  }
  return(similarity)
}

##################################################################################################################################################################


# cube each iten the the similarity matrix so that relevant items have more influence than less relevant items
get_activation<-function(similarity){
  return(similarity^3)
}

##################################################################################################################################################################

# sum the columns of the activation matrix to get a measure of intensity (how "familiar" is the probe i)
get_intensity<-function(activation){
  return(colSums(activation))
}

##################################################################################################################################################################


# get the content of the echo
get_echo<-function(activation,
                   memory,
                   type = "normed",
                   rounding_digits = 0){

  good_type_input<-type%in%c("raw","normed","rounded")
  if (good_type_input == F){stop("Improper echo type specified")}

  if (nrow(memory)==0){return(matrix(rep(0,ncol(memory)),nrow = 1))}


  # get the echo by multiplying the activation matrix by the memory
  echo<-t(activation)%*%memory

  # if the user asks for the raw echo then return it
  if (type == "raw"){return(echo)}

  # normalize the echo by dividing each number in an instance by the largest number in that instance
  normed_echo<-echo
  nrow<-0
  while (nrow < nrow(normed_echo)){
    nrow<-nrow+1
    normed_echo[nrow,]<-normed_echo[nrow,]/max(abs(normed_echo[nrow,]))
  }

  # if the user asks for the normed echo (default setting) then return it
  if (type == "normed"){return(normed_echo)}

  # if the user asks for the rounded echo then return the rounded normed echo (default is to 0 sig digits for whole numbers comparison with probe)
  if(type == "rounded"){return(round(normed_echo,digits = rounding_digits))}

}
##################################################################################################################################################################

add_noise<-function(echo){
  for (i in 1:length(echo)){
    echo[i]<-echo[i]+runif(1,-0.001,0.001)
  }
  return(echo)
}

##################################################################################################################################################################


add_distortion<-function(instance,
                         proportion = 0.3,
                         name_first = T){
  len<-round(length(instance)/2,0)
  number_to_distort<-round(len*proportion,0)
  distort_list<-c()
  repeat{
    new_num<-round(runif(1,1,len),0)
    if (new_num %in% distort_list){} # do nothing
    else{
      distort_list<-c(distort_list,new_num)
    }
    if (length(distort_list)==number_to_distort){
      break
    }
  }

  if (name_first == T){
    distort_list<-distort_list+len
  }


  for (i in distort_list){
    instance[i]<-(-1)*instance[i]
  }

  return(instance)
}

##################################################################################################################################################################

correlate_echo_names<-function(echo,
                               category,
                               name_first = T){
  len<-round(length(echo)/2,0)+1
  #if (name_first == F){return(cor(echo[len+1:length(echo)],category[len+1:length(echo)]))}
  #else{return(cor(echo[1:len],category[1:len]))}
  # print(echo)
  # print(category)
  # echo_cor<-(echo[len:length(echo)])
  # cat_cor<-(category[len:length(echo)])
  # print(echo_cor)
  # print(cat_cor)
  # print(cor(echo_cor,cat_cor))
  # print(cor(echo[len:length(echo)],category[len:length(echo)]))
  return(cor(echo[len:length(echo)],category[len:length(echo)]))
}

##################################################################################################################################################################

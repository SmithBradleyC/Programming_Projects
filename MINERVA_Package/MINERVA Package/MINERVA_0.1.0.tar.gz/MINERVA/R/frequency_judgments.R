frequency_judgments<-function(sub = 50,
                             num_items =40,
                             number_of_categories = 3,
                             # list specifying number in each category
                             frequency_of_categories = c(10,50,100),
                             number_of_distractors = 0,
                             forget_proportion = 0.5,
                             type = "normed",
                             sig_digits = 2,
                             ...){

  # for when you want to do the follow up test with forgetting
  L = 1-forget_proportion

  # if the parameters don't match up flag error
  if (number_of_categories != length(frequency_of_categories)){stop("Must specify how many instances in each category")}

  # make a matrix to store the prototypes in to remember later
  prototype_matrix<-matrix(ncol = num_items,nrow = 0)
  for (i in 1:number_of_categories){
    prototype<-make_instance(num_items = num_items)
    prototype_matrix<-rbind(prototype_matrix,prototype)
  }

  # set up items to be able to average intensity and echo over participants
  t_intensity<-0
  t_echo<-0
  list_intensity<-c()
  ####make list of lists to make histograms of intensities latter
  ####list_intensity<-(rep(c(0),number_of_categories))
  ####rep( list(list()), 3 )


  # repeat experiment with same prototypes over several participants
  for (par in 1:sub){

    # initiate memory
    memory<-initiate_memory(num_items = num_items)

    for (i in 1:number_of_categories){
      prototype<-prototype_matrix[i,]
      for (y in 1:frequency_of_categories[i]){
        #memory<-add_to_memory(add_distortion(instance = prototype,proportion = distortion_proportion),memory = memory)
        memory<-add_to_memory(prototype,memory = memory,L)
      }
    }
    #distractor<-make_instance(num_items = num_items)
    #prototype_matrix<-rbind(prototype_matrix,distractor)
    rownames(prototype_matrix)<-NULL

    # make a probe matrix for testing
    probe<-c()

      distractor<-make_instance(num_items = num_items)
      #prototype_matrix<-rbind(prototype_matrix,distractor)
      #rownames(prototype_matrix)<-NULL
      probe<-prototype_matrix
      probe<-rbind(probe,distractor)
      rownames(probe)<-NULL


      # for (i in (num_items/2+1):num_items){
      #   probe[,i]<-c(rep(0,nrow(probe)))
      # }

      names<-c()
      for (i in 1:number_of_categories){
        names<-c(names,paste("Prototype ",i))
      }
      names_col<-c(names,"Distractor")
      names_row<-c("Actual Frequency", "Echo Intensity")
      number_of_rows<-number_of_categories+1






    #print(memory)
    #print(t(probe))
    similarity<-get_similarity(memory,t(probe))
    activation<-get_activation(similarity)
    #print(activation)

    intensity<-get_intensity(activation)
    #echo<-get_echo(activation, memory,type = type)

    #get list of intensities across subjects for histogram
    #for (i in 1:number_of_categories){
    #  list_intensity[i] = c(list_intensity[i],intensity[i])
    #}
    list_intensity<-c(list_intensity,intensity)

    # sum up total intensity and echo
    t_intensity<-t_intensity+intensity
    #t_echo<-t_echo+echo

  }

  # average out intensity and echo
  a_intensity<-t_intensity/sub

  number<-(length(list_intensity))

  dens<-c()
  for (i in 1:sub){
    dens<-c(dens,list_intensity[(i*(number_of_categories+1)-(number_of_categories))])
    number<-number-1
  }
  par(mfrow = c(1,1))
  plot(density(dens), xlim = c(0,max(list_intensity)), main = "", xlab = "Echo Intensity")
  for (j in 1:(number_of_categories-1)){
    dens<-c()
    for (i in 1:sub){

      dens<-c(dens,list_intensity[(i*(number_of_categories+1)-(number_of_categories))+j])
      number<-number-1
    }
    lines(density(dens))
  }
  print(number)
  return(as.table(matrix(c(c(frequency_of_categories,0), round(a_intensity,digits = 3)),
                         nrow = number_of_rows, byrow = FALSE,
                         dimnames = list(names_col,names_row))))
}
